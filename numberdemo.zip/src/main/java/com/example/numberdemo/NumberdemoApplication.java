package com.example.numberdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NumberdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(NumberdemoApplication.class, args);
	}

}
