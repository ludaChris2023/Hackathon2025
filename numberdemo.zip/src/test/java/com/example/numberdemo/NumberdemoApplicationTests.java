package com.example.numberdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NumberdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
